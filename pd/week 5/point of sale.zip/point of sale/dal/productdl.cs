﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace point_of_sale.dal
{
   public  class productdl
    {
        public static List<models.Product> products = new List<models.Product>();

    }
}
